Snow steps recorded by Corsica_S http://virb.com/corsica_s / http://www.freesound.org/usersViewSingle.php?id=7037

Sources are http://www.freesound.org/samplesViewSingle.php?id=28661 and http://www.freesound.org/samplesViewSingle.php?id=28662

Permission was given to extract the sounds and release them under cc0 http://creativecommons.org/publicdomain/zero/1.0/ (many thanks!)

The extracted sounds were extracted by Iwan Gabovitch and published on opengameart.org
